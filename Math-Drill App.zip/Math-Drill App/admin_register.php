<?php
session_start();
include('db.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = trim($_POST['name']);
    $password = trim($_POST['pass']);
    $confirm_password = trim($_POST['confirm_pass']);
    $error_message = '';
    $success_message = '';

    if (empty($name) || empty($password) || empty($confirm_password)) {
        $error_message = "All fields are required.";
    } elseif ($password !== $confirm_password) {
        $error_message = "Passwords do not match.";
    } else {
        // Hash password
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Check if admin already exists
        $stmt = $conn->prepare("SELECT user_id FROM users WHERE name = ? AND role = 'admin'");
        $stmt->bind_param("s", $name);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $error_message = "Admin with this name already exists!";
        } else {
            // Insert new admin
            $stmt = $conn->prepare("INSERT INTO users (name, password, role) VALUES (?, ?, 'admin')");
            $stmt->bind_param("ss", $name, $hashed_password);
            if ($stmt->execute()) {
                $success_message = "Admin account created successfully! You can now <a href='admin_login.php'>Login</a>.";
            } else {
                $error_message = "Error creating account. Try again.";
            }
        }
        $stmt->close();
    }
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Registration - Math Learning App</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <form action="" method="post" autocomplete="off" class="container">
        <h1>Register Admin</h1>
        <p>Create a temporary admin account</p>

        <div class="input-section">
            <input type="text" name="name" required maxlength="50" placeholder="Enter Admin Name" class="box">
            <input type="password" name="pass" required maxlength="20" placeholder="Enter Password" class="box">
            <input type="password" name="confirm_pass" required maxlength="20" placeholder="Confirm Password" class="box">
            
            <?php if (!empty($error_message)): ?>
                <p style="color: red;"><?php echo $error_message; ?></p>
            <?php endif; ?>
            
            <?php if (!empty($success_message)): ?>
                <p style="color: green;"><?php echo $success_message; ?></p>
            <?php endif; ?>

            <input type="submit" value="Register Admin" class="btn">
        </div>
    </form>

    <script src="script.js"></script>
</body>
</html>
