<?php
session_start();
include('db.php');

if (!isset($_SESSION["name"]) || !isset($_POST["lesson_name"])) {
    die("Unauthorized access");
}

$name = $_SESSION["name"];
$lesson_name = $_POST["lesson_name"];

// Get user ID
$stmt = $conn->prepare("SELECT id, completed_lessons FROM users WHERE name = ?");
$stmt->bind_param("s", $name);
$stmt->execute();
$stmt->bind_result($user_id, $completed_lessons);
$stmt->fetch();
$stmt->close();

// Check if lesson is already completed
$stmt = $conn->prepare("SELECT COUNT(*) FROM lesson_progress WHERE user_id = ? AND lesson_name = ?");
$stmt->bind_param("is", $user_id, $lesson_name);
$stmt->execute();
$stmt->bind_result($lesson_count);
$stmt->fetch();
$stmt->close();

if ($lesson_count == 0) {
    // Insert into lesson_progress
    $stmt = $conn->prepare("INSERT INTO lesson_progress (user_id, lesson_name) VALUES (?, ?)");
    $stmt->bind_param("is", $user_id, $lesson_name);
    $stmt->execute();
    $stmt->close();

    // Update total completed lessons
    $completed_lessons += 1;
    $stmt = $conn->prepare("UPDATE users SET completed_lessons = ? WHERE id = ?");
    $stmt->bind_param("ii", $completed_lessons, $user_id);
    $stmt->execute();
    $stmt->close();
}

$conn->close();

// Send JSON response
echo json_encode(["success" => true, "new_badge" => ($completed_lessons <= 4) ? "badge" . $completed_lessons . ".png" : null]);
?>
