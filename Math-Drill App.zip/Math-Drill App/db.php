<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "math";

$conn = new mysqli($servername, $username, $password, $dbname);

if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}

?>
