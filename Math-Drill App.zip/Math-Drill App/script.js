let currentAvatar = "images/avatar/avatar1.png"; 

// Open avatar modal
function openAvatarModal() {
    let modal = document.getElementById("avatar-modal");
    let avatarGrid = document.querySelector(".avatar-grid");
    avatarGrid.innerHTML = ""; 

    for (let i = 1; i <= 9; i++) {
        let img = document.createElement("img");
        img.src = `images/avatar/avatar${i}.png`;
        img.onclick = function () { 
            selectAvatar(`images/avatar/avatar${i}.png`); 
        };
        avatarGrid.appendChild(img);
    }
    modal.style.display = "flex";
}

// Select an avatar and update hidden input
function selectAvatar(avatarPath) {
    currentAvatar = avatarPath;
    document.getElementById("selected-avatar").src = avatarPath;
    document.getElementById("avatar").value = avatarPath; // Update hidden input
    closeAvatarModal();
}

// Close the avatar modal
function closeAvatarModal() {
    document.getElementById("avatar-modal").style.display = "none";
}
