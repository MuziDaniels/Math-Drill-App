<?php
session_start();
include('db.php');

if (!isset($_SESSION["name"])) {
    echo "User not logged in";
    exit();
}

$name = $_SESSION["name"];

// Update user's progress (e.g., increase points and completed lessons)
$stmt = $conn->prepare("UPDATE users SET ubuntu_points = ubuntu_points + 10, completed_lessons = completed_lessons + 1 WHERE name = ?");
$stmt->bind_param("s", $name);

if ($stmt->execute()) {
    echo "Progress updated successfully!";
} else {
    echo "Error updating progress.";
}

$stmt->close();
$conn->close();
?>
