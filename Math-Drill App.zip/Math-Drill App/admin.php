<?php
session_start();
include('db.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = trim($_POST['name']);
    $password = trim($_POST['pass']);
    $error_message = '';

    if (empty($name) || empty($password)) {
        $error_message = "Both fields are required.";
    } else {
        $stmt = $conn->prepare("SELECT password FROM users WHERE name = ? AND role = 'admin'");
        $stmt->bind_param("s", $name);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $stmt->bind_result($hashed_password);
            $stmt->fetch();
            if (password_verify($password, $hashed_password)) {
                $_SESSION['admin_name'] = $name;
                header("Location: admin_dashboard.php");
                exit();
            } else {
                $error_message = "Incorrect password.";
            }
        } else {
            $error_message = "No admin account found.";
        }
        $stmt->close();
    }
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - Math Learning App</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <form action="" method="post" autocomplete="off" class="container">
        <h1>Admin Panel</h1>
        <p>Manage student progress and lessons</p>

        <div class="input-section">
            <input type="text" name="name" required maxlength="50" placeholder="Enter Admin Name" class="box" aria-label="Enter Admin Name">
            <input type="password" name="pass" required maxlength="20" placeholder="Enter Password" class="box" aria-label="Enter Password">
            <?php if (!empty($error_message)): ?>
                <p style="color: red;"><?php echo $error_message; ?></p>
            <?php endif; ?>

            <input type="submit" value="Login Now" name="submit" class="btn">
        </div>
    </form>

    <script src="script.js"></script>
</body>
</html>
