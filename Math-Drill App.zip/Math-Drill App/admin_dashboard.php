<?php
session_start();
if (!isset($_SESSION["admin_name"])) {
    header("Location: admin_login.php");
    exit();
}

include('db.php');

// Get admin information
$admin_name = $_SESSION["admin_name"];

// Get total users
$stmt = $conn->prepare("SELECT COUNT(*) FROM users WHERE role = 'student'");
$stmt->execute();
$stmt->bind_result($total_users);
$stmt->fetch();
$stmt->close();

// Get total lessons completed
$stmt = $conn->prepare("SELECT SUM(completed_lessons) FROM users WHERE role = 'student'");
$stmt->execute();
$stmt->bind_result($total_lessons_completed);
$stmt->fetch();
$stmt->close();

// Get leaderboard (top learners)
$stmt = $conn->prepare("SELECT name, ubuntu_points FROM users WHERE role = 'student' ORDER BY ubuntu_points DESC LIMIT 5");
$stmt->execute();
$stmt->bind_result($top_name, $top_points);
$leaderboard = [];
while ($stmt->fetch()) {
    $leaderboard[] = ['name' => $top_name, 'points' => $top_points];
}
$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Math Learning App</title>
    <link rel="stylesheet" href="style.css">
    <style>
        /* Admin Panel Styling */
        .container-dash {
            padding: 20px;
        }

        .admin-card {
            padding: 15px;
            border-radius: 10px;
            box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.2);
            text-align: center;
            margin-bottom: 15px;
        }

        .leaderboard {
            list-style-type: none;
            padding: 0;
        }

        .leaderboard li {
            background: #f4f4f4;
            margin: 5px 0;
            padding: 10px;
            border-radius: 5px;
        }

        .btn {
            padding: 8px 15px;
            border: none;
            background: #d9534f;
            color: white;
            cursor: pointer;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <div class="container-dash">
        <!-- Welcome Banner -->
        <div class="welcome-banner">
            <h2>Welcome Admin, <?php echo htmlspecialchars($admin_name); ?>!</h2>
            <button onclick="window.location.href='admin_logout.php'" class="btn">Logout</button>
        </div>

        <!-- Admin Stats -->
        <div class="progress-section">
            <div class="admin-card">
                <h3>👥 Total Learners</h3>
                <p><?php echo $total_users; ?> learners registered</p>
            </div>

            <div class="admin-card">
                <h3>📚 Lessons Completed</h3>
                <p><?php echo $total_lessons_completed; ?> total lessons completed</p>
            </div>

            <div class="admin-card">
                <h3>🏆 Top Learners</h3>
                <ul class="leaderboard">
                    <?php foreach ($leaderboard as $learner): ?>
                        <li><?php echo htmlspecialchars($learner['name']) . " - " . $learner['points'] . " points"; ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
    </div>
</body>
</html>
