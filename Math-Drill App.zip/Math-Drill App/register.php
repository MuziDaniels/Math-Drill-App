<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Math Learning App</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <form action="" method="post" autocomplete="off" class="container">
        <h1>Welcome to Math Fun!</h1>
        <p>Lets learn some fun math</p>

        <?php
        // Include the database connection file
        include('db.php');

        // Initialize variables
        $name = $password = $cpassword = '';
        $errors = [];
        $success = "";

        // Form submission handling
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $name = trim($_POST['name']);
            $password = trim($_POST['pass']);
            $cpassword = trim($_POST['c_pass']);
            $avatar = trim($_POST['avatar']); 
        
        // Validate inputs
        if (empty($name) || empty($password) || empty($cpassword)) {
            $errors[] = "All fields are required.";
        } elseif ($password !== $cpassword) {
            $errors[] = "Passwords do not match.";
        }

         // If no errors, proceed with registration
            if (empty($errors)) {
                // Hash the password
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);

                // Prepare SQL statement
                $stmt = $conn->prepare("INSERT INTO users (name, password, avatar) VALUES (?, ?, ?)");
                $stmt->bind_param("sss", $name, $hashed_password, $avatar);

                // Execute and check if successful
                if ($stmt->execute()) {
                    $success = "Registration successful! You can <a href='login.php'>login now</a>.</p>";
                } else {
                    echo "Error: " . $stmt->error;
                }

                // Close statement
                $stmt->close();
            } else {
                foreach ($errors as $error) {
                    echo "<p>$error</p>";
                }
            }
        }

        // Close the database connection
        $conn->close();
        ?>

        <!-- Avatar Selection -->
        <div class="avatar-section">
            <img id="selected-avatar" src="images/avatar/avatar1.png" alt="Avatar" onclick="openAvatarModal()">
            <p>Click on the avatar to select the one you like.</p>
        </div>

        <input type="hidden" id="avatar" name="avatar" value="images/avatar/avatar1.png">
        
        <!-- Enter Name Section-->
        <div class="input-section">
            <input type="text"id="name" name="name" required maxlength="50" placeholder="Enter your name" class="box" aria-label="Enter your name" value="<?php echo htmlspecialchars($name); ?>">
            <input type="password" id="password" name="pass" required maxlength="20" placeholder="Enter your password" class="box" aria-label="Enter your password">
            <input type="password" id="cpassword" name="c_pass" required maxlength="20" placeholder="Confirm your password" class="box" aria-label="Confirm your password">
            
            <!-- Display success message in green -->
            <?php if ($success): ?>
                <p style="color: green;"><?php echo $success; ?></p>
            <?php endif; ?>

            <!-- Display error messages in red -->
            <?php if (!empty($errors)): ?>
                <?php foreach ($errors as $error): ?>
                <p style="color: red;"><?php echo $error; ?></p>
                <?php endforeach; ?>
            <?php endif; ?>
            <p>Already have an account? <a href="login.php">Login</a></p>
            <input type="submit" value="Register" name="submit" class="btn">
        </div>
    </form>

    <!-- Avatar Selection Modal -->
    <div id="avatar-modal" class="modal">
        <div class="modal-content">
            <h2>Select Your Avatar</h2>
            <div class="avatar-grid">
            </div>
            <button onclick="closeAvatarModal()">Close</button>
        </div>
    </div>

    <script src="script.js"></script>
</body>
</html>
