<?php
session_start();
if (!isset($_SESSION["name"])) {
    header("Location: login.php");
    exit();
}

include('db.php');

// Get user information
$name = $_SESSION["name"];
$stmt = $conn->prepare("SELECT avatar FROM users WHERE name = ?");
$stmt->bind_param("s", $name);
$stmt->execute();
$stmt->bind_result($avatar);
$stmt->fetch();
$stmt->close();
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lesson 1: Addition</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .video-container {
            width: 50%;
            max-width: 500px;
            margin: 0 auto; /* Centers horizontally */
            text-align: center; /* Ensures inline elements are centered */
        }

        video {
            width: 100%; /* Makes sure the video scales responsively */
            max-width: 600px; /* Adjust this as needed */
            height: auto;
            border: 2px solid #333;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.3);
        }
       
        .button-container {
            display: flex;
            justify-content: center; /* Centers button horizontally */
            margin-top: 20px;
        }

        #next-btn {
            display: none;
            padding: 10px 20px;
            font-size: 18px;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        #next-btn:hover {
            background-color: #218838;
        }
        /* Quiz Section */
        .quiz-container {
            display: none;
            text-align: center;
            margin-top: 20px;
        }

        .options button {
            padding: 10px 15px;
            margin: 5px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 5px;
            border: 2px solid #333;
        }

        .options button.correct {
            background-color: #4CAF50;
            color: white;
        }

        .options button.wrong {
            background-color: #ff4444;
            color: white;
        }
        @keyframes badgeFadeIn {
            0% { transform: scale(0); opacity: 0; }
            50% { transform: scale(1.2); opacity: 1; }
            100% { transform: scale(1); }
        }

        .badge-animation {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 100px;
            height: 100px;
            animation: badgeFadeIn 1.5s ease-in-out;
            z-index: 1000;
        }

    </style>
</head>
<body>
    <div class="container-dash">
        <div class="welcome-banner">
            <img src="<?php echo htmlspecialchars($avatar); ?>" alt="User Avatar" class="user-avatar">
            <h2>Hey <?php echo htmlspecialchars($name); ?>! Let's Learn Addition</h2>
        </div>

        <!-- Video Container -->
        <h1>Lesson 1 - Video Player</h1>
        <div class="video-container">
            <video id="videoPlayer" controls>
                <source id="videoSource" src="Lesson1/intro.mp4" type="video/mp4">
                Your browser does not support the video tag.
            </video>
            <div class="button-container">
                <button id="next-btn" onclick="playNextVideo()">Next ➔</button>
                <button id="finish-btn" style="display: none;" onclick="finishLesson()">Finish ✅</button>
            </div>
        </div>

        <!-- Quiz Section -->
        <div class="quiz-container" id="quiz-container">
            <h3 id="quiz-question"></h3>
            <div class="options" id="quiz-options"></div>
        </div>

        <!-- Sound Effects -->
        <audio id="correct-sound" src="Music/correct.mp3"></audio>
        <audio id="wrong-sound" src="Music/wrong.mp3"></audio>
    </div>
   
    <script>
        // Video sequence
        const scenes = [
            "Lesson1/intro.mp4",
            "Lesson1/scene1.mp4",
            "Lesson1/scene2.mp4",
            "Lesson1/scene3.mp4",
            "Lesson1/scene4.mp4",
            "Lesson1/scene5.mp4",
            "Lesson1/scene6.mp4"
        ];

        // Corresponding quiz questions and answers
        const quizzes = [
            null, // No quiz for the intro
            {
                question: "How much are the soccer boots?",
                options: [130, 150, 120],
                correct: 150
            },
            {
                question: "How much did Mkhulu give Thabo?",
                options: [50, 80, 30],
                correct: 50
            },
            {
                question: "How much did Mom give Thabo?",
                options: [80, 50, 100],
                correct: 80
            },
            {
                question: "How much does Thabo have in his piggy bank?",
                options: [10, 15, 20],
                correct: 20
            },
            {
                question: "How much does Thabo have in total? R50 + R80 + R20 =",
                options: [100, 130, 150],
                correct: 150
            }
    
        ];

        let currentScene = 0;
        const videoPlayer = document.getElementById("videoPlayer");
        const videoSource = document.getElementById("videoSource");
        const nextButton = document.getElementById("next-btn");
        const quizContainer = document.getElementById("quiz-container");
        const quizQuestion = document.getElementById("quiz-question");
        const quizOptions = document.getElementById("quiz-options");

        // Function to load and play the next video
        function playNextVideo() {
            currentScene++;

            if (currentScene < scenes.length) {
                videoSource.src = scenes[currentScene];
                videoPlayer.load();
                videoPlayer.play();
                nextButton.style.display = "none"; 
                quizContainer.style.display = "none"; 
            } else {
                nextButton.style.display = "none";
                document.getElementById("finish-btn").style.display = "block"; // Show Finish button
            }
        }


        // Function to display the quiz
        function showQuiz(sceneIndex) {
            if (quizzes[sceneIndex]) {
                quizQuestion.innerText = quizzes[sceneIndex].question;
                quizOptions.innerHTML = ""; // Clear old options

                quizzes[sceneIndex].options.forEach(option => {
                    const button = document.createElement("button");
                    button.innerText = "R" + option;
                    button.onclick = () => checkAnswer(option, button, sceneIndex);
                    quizOptions.appendChild(button);
                });

                quizContainer.style.display = "block"; // Show quiz
            } else {
                nextButton.style.display = "block"; // Show next button for non-quiz videos
            }
        }

        // Function to check the answer
        function checkAnswer(selected, button, sceneIndex) {
            if (selected === quizzes[sceneIndex].correct) {
                document.getElementById('correct-sound').play();
                button.classList.add("correct");

                setTimeout(() => {
                    quizContainer.style.display = "none";

                    if (sceneIndex === quizzes.length - 1) {
                        document.getElementById("finish-btn").style.display = "block"; // Show Finish button for last quiz
                    } else {
                        nextButton.style.display = "block"; 
                    }
                }, 1000);
            } else {
                document.getElementById('wrong-sound').play();
                button.classList.add("wrong");
                setTimeout(() => button.classList.remove("wrong"), 500);
            }
        }
        function finishLesson() {
            fetch('update_progress.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'update=true'
            })
            .then(response => response.text())
            .then(data => {
                alert("Lesson Completed! 🎉 Your progress has been saved.");
                window.location.href = "dashboard.php"; // Redirect to dashboard or next lesson
            })
            .catch(error => console.error('Error:', error));
        }



        // Event listener: When video ends, show quiz or next button
        videoPlayer.addEventListener("ended", function() {
            if (currentScene < scenes.length - 1) {
                showQuiz(currentScene);
            }
        });

        // Autoplay the first video
        videoPlayer.load();
        videoPlayer.play();
    </script>
    <script>
        function completeLesson(lessonName) {
            fetch("complete_lesson.php", {
                method: "POST",
                headers: { "Content-Type": "application/x-www-form-urlencoded" },
                body: "lesson_name=" + encodeURIComponent(lessonName)
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Show badge animation if new badge earned
                    if (data.new_badge) {
                        showBadgeAnimation(data.new_badge);
                    }

                    // Redirect back to the dashboard
                    setTimeout(() => { window.location.href = "dashboard.php"; }, 3000);
                }
            });
        }

        function showBadgeAnimation(badgeImg) {
            const badge = document.createElement("img");
            badge.src = "badges/" + badgeImg;
            badge.classList.add("badge-animation");
            document.body.appendChild(badge);

            setTimeout(() => { badge.remove(); }, 3000);
        }
</script>

</body>
</html>
