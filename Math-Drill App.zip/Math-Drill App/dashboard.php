<?php
    session_start();
    if (!isset($_SESSION["name"])) {
        header("Location: login.php");
        exit();
    }

    include('db.php');

    // Get user information
    $name = $_SESSION["name"];
    $stmt = $conn->prepare("SELECT avatar, ubuntu_points, completed_lessons FROM users WHERE name = ?");
    $stmt->bind_param("s", $name);
    $stmt->execute();
    $stmt->bind_result($avatar, $ubuntu_points, $completed_lessons);
    $stmt->fetch();
    $stmt->close();
    $conn->close();

    $total_lessons = 4; 
    $progress_percentage = ($completed_lessons / $total_lessons) * 100;
    $progress_percentage = min($progress_percentage, 100); 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Math Learning App - Dashboard</title>
    <link rel="stylesheet" href="style.css">
    <style>
        /* Progress Bar */
        .progress-bar {
            width: 100%;
            background: #ddd;
            border-radius: 10px;
            overflow: hidden;
            height: 20px;
            margin-top: 10px;
        }

        .progress-bar div {
            height: 100%;
            background: #4CAF50;
            text-align: center;
            color: white;
            line-height: 20px;
            font-size: 14px;
        }

        /* Badge Styles */
        .badge-container {
            display: flex;
            gap: 10px;
        }

        .badge {
            width: 50px;
            height: 50px;
            margin: 10px;
            padding-left: 10px;
            padding-right: 10px;
        }

        /* Lesson Card Styles */
        .lesson-card {
            padding: 15px;
            border-radius: 10px;
            box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.2);
            text-align: center;
            margin-bottom: 15px;
        }

        .btn {
            padding: 8px 15px;
            border: none;
            background: #28a745;
            color: white;
            cursor: pointer;
            border-radius: 5px;
        }

        .btn:disabled {
            background: gray;
            cursor: not-allowed;
        }

        .progress {
            margin-top: 10px;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="container-dash">

        <!-- Welcome Banner -->
        <div class="welcome-banner">
            <img src="<?php echo htmlspecialchars($avatar); ?>" alt="User Avatar" class="user-avatar">
            <h2>Welcome <?php echo htmlspecialchars($name); ?>!, you have <?php echo htmlspecialchars($ubuntu_points); ?> points</h2>
            <button onclick="window.location.href='logout.php'" class="btn">Logout</button>
        </div>

        <!-- Progress Section -->
        <div class="progress-section">
            <div class="progress-card">
                <h3>📚 Your Progress</h3>
                <div class="progress-bar">
                    <div style="width: <?php echo $progress_percentage; ?>%;"><?php echo round($progress_percentage); ?>%</div>
                </div>
                <p><?php echo round($progress_percentage); ?>% Complete - Keep going!</p>
            </div>

            <div class="progress-card">
                <h3>🏆 Latest Badges</h3>
                <div class="badge-container">
                    <?php
                    if ($completed_lessons >= 1) echo '<img src="Badges/Badge1.png" class="badge" alt="Addition Ace">';
                    if ($completed_lessons >= 2) echo '<img src="badges/badge-subtraction.png" class="badge" alt="Subtraction Star">';
                    if ($completed_lessons >= 3) echo '<img src="badges/badge-multiplication.png" class="badge" alt="Multiplication Master">';
                    if ($completed_lessons >= 4) echo '<img src="badges/badge-division.png" class="badge" alt="Division Genius">';
                    ?>
                </div>
            </div>
        </div>

        <!-- Lessons Grid -->
        <h2>Start Learning ⚽</h2>
        <div class="lesson-grid">
            <!-- Lesson 1: Addition -->
            <div class="lesson-card" style="background: #FFF9C4;">
                <h3>➕ Addition</h3>
                <p>Buy Soccer Boots</p>
                <button onclick="window.location.href='addition.php'" class="btn">Start Lesson</button>
                <div class="progress"><?php echo ($completed_lessons >= 1) ? '✔️ Completed' : '▶️ Start'; ?></div>
            </div>

            <!-- Lesson 2: Subtraction -->
            <div class="lesson-card" style="background: #FFCDD2;">
                <h3>➖ Subtraction</h3>
                <p>Track Match Time</p>
                <button onclick="window.location.href='subtraction.php'" class="btn" <?php echo ($completed_lessons < 1) ? 'disabled' : ''; ?>>Start Lesson</button>
                <div class="progress"><?php echo ($completed_lessons >= 2) ? '✔️ Completed' : (($completed_lessons >= 1) ? '▶️ Continue' : '🔒 Locked'); ?></div>
            </div>

            <!-- Lesson 3: Multiplication -->
            <div class="lesson-card" style="background: #C5E1A5;">
                <h3>✖️ Multiplication</h3>
                <p>Game Score Multiplication</p>
                <button onclick="window.location.href='multiplication.php'" class="btn" <?php echo ($completed_lessons < 2) ? 'disabled' : ''; ?>>Start Lesson</button>
                <div class="progress"><?php echo ($completed_lessons >= 3) ? '✔️ Completed' : (($completed_lessons >= 2) ? '▶️ Continue' : '🔒 Locked'); ?></div>
            </div>

            <!-- Lesson 4: Division -->
            <div class="lesson-card" style="background: #B3E5FC;">
                <h3>➗ Division</h3>
                <p>Split Game Points</p>
                <button onclick="window.location.href='division.php'" class="btn" <?php echo ($completed_lessons < 3) ? 'disabled' : ''; ?>>Start Lesson</button>
                <div class="progress"><?php echo ($completed_lessons >= 4) ? '✔️ Completed' : (($completed_lessons >= 3) ? '▶️ Continue' : '🔒 Locked'); ?></div>
            </div>
        </div>
    </div>


</body>
</html>