<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Math Learning App</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <form action="" method="post" autocomplete="off" class="container">
        <h1>Welcome to Math Fun!</h1>
        <p>Lets learn some fun math</p>

        <?php

        // Start the session
        session_start();

        // Include the database connection file
        include('db.php');

        // Initialize variables
        $name = $password = '';
        $error_message = '';

        // Form submission handling
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $name = trim($_POST['name']);
            $password = trim($_POST['pass']);

            // Validate inputs
            if (empty($name) || empty($password)) {
                $error_message = "Both fields are required.";
            } else {
                // Prepare SQL statement to prevent SQL injection
                $stmt = $conn->prepare("SELECT password FROM users WHERE name = ?");
                $stmt->bind_param("s", $name);
                $stmt->execute();
                $stmt->store_result();

                // Check if the name exists
                if ($stmt->num_rows > 0) {
                    $stmt->bind_result($hashed_password);
                    $stmt->fetch();

                    // Verify the password
                    if (password_verify($password, $hashed_password)) {
                        // Set session variables
                        $_SESSION['name'] = $name;
                        header("Location: dashboard.php");
                        exit();
                    } else {
                        $error_message = "Incorrect password.";
                    }
                } else {
                    $error_message = "No account found with that name.";
                }

                // Close statement
                $stmt->close();
            }
        }

        // Close the database connection
        $conn->close();
        ?>

        <div class="input-section">
            <input type="text" id="name" name="name" required maxlength="50" placeholder="Enter your name" class="box" aria-label="Enter your name" value="<?php echo htmlspecialchars($name); ?>">
            <input type="password" id="password" name="pass" required maxlength="20" placeholder="Enter your password" class="box" aria-label="Enter your password">
            <?php if ($error_message): ?>
                <p style="color: red;"><?php echo $error_message; ?></p>
            <?php endif; ?>

            <p>Don't have an account? <a href="register.php">Register</a></p>
            <input type="submit" value="Login Now" name="submit" class="btn">
        </div>

    </form>

    <script src="script.js"></script>
</body>
</html>
